<footer class="logoDarkTitle" style="height: 75px; padding-top: 15px;">
  <center>
    		PVKN GOVT COLLEGE AUTONOMOUS CHITTOOR AP
    		<br>
    		Re-Accredited by NACC with 'A' Grade
  </center>
</footer>