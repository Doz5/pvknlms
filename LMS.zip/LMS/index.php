<?php 
	header('Location:Home');
?>